To run the new test cases, copy the new test files and test script into the folder where your current test script is. It will overwrite your old test script. The new test script runs all the old test files and the new ones. Do not delete the old test files.

DO THIS ONLY ONCE, run this command in the command line: chmod 777 testrun

To run the test file is the same as before: ./testrun <your_student_number>

Good luck, have fun! :-D
